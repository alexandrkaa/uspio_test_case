export const SLIDER_LOOP = 5000;
export const SLIDER_2_ITEMS_SIZE = 1024;
export const SLIDER_1_ITEM_SIZE = 768;