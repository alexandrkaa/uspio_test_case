import $ from 'jquery'; // from node_modules
window.jQuery = $;
export default $;